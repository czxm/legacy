#!/bin/sh

function print_usage() {
    echo "Usage: ./silent_install.sh [OPTION]..."
    echo -e "\nValid options are:"
    echo -e "-pfn  <pkg_file_full_name>\tpackage file full name"
    echo -e "-pn   <pkg_file_name_prefix>\tpackage file name prefix, defaults to intelhadoop"
    echo -e "-repo <abs_path_IDH_repo>\tabsolute path for IDH repo, defaults to /var/ftp/pub/idh"
    echo -e "-plf  <platform>\tplatform info, defaults to cent6.2"
    echo -e "-h\tdisplay this help and exit"
}

#init var
abs_path_IDH_repo=/var/ftp/pub/idh
pkg_file_full_name=intelhadoop.tar.gz
pkg_file_name_prefix=intelhadoop
abs_path_IDH_repo=/var/ftp/pub/idh
platform=cent6.2 ## could be cent6.1/cent6.2/cent6.3/rhel6.1/rhel6.2/rhel6.3/oel6.2/oel6.3

#input param
while [ $# -gt 0 ]
do
    case "$1" in
      -pfn) pkg_file_full_name="$2"; shift;;
      -pn) pkg_file_name_prefix="$2"; shift;;
      -repo) abs_path_IDH_repo="$2"; shift;;
      -plf) platform="$2"; shift;;
      -h)
          print_usage
          exit 0;;
      *)
          print_usage
          exit 0;;
    esac
    shift
done
echo "++pkg_file_full_name: $pkg_file_full_name"
echo "++pkg_file_name_prefix: $pkg_file_name_prefix"
echo "++abs_path_IDH_repo: $abs_path_IDH_repo"
echo "++platform: $platform"


#decompression
if [ -z ${pkg_file_full_name} ];then
	echo "Incorrect release package file full name -- ${pkg_file_full_name}!!"
	exit 0;
fi
rm -rf ${pkg_file_name_prefix}
tar zxvf ${pkg_file_full_name}

#create IDH repo
TMP_IDH_REPO_DIR=IDH_REPO
mkdir -p ${pkg_file_name_prefix}/${TMP_IDH_REPO_DIR}
mv ${pkg_file_name_prefix}/idh ${pkg_file_name_prefix}/${TMP_IDH_REPO_DIR}
mv ${pkg_file_name_prefix}/manager ${pkg_file_name_prefix}/${TMP_IDH_REPO_DIR}
mv ${pkg_file_name_prefix}/os_related ${pkg_file_name_prefix}/${TMP_IDH_REPO_DIR}
createrepo ${pkg_file_name_prefix}/${TMP_IDH_REPO_DIR}

mkdir -p ${abs_path_IDH_repo}
rm -rf ${abs_path_IDH_repo}
mv ${pkg_file_name_prefix}/IDH_REPO ${abs_path_IDH_repo}
#TODO: vsftpd restart

#silent install
sed 's/###PLATFORM###/'"${platform}"'/g' ui_installer_conf_tmpl >ui_installer_conf
cp -f ui_installer_conf ${pkg_file_name_prefix}/ui-installer/conf
${pkg_file_name_prefix}/ui-installer/install

